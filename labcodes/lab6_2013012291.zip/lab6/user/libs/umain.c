#include <ulib.h>

int main(void);

void
umain(void) {
    int ret = main();
    exit(ret);
}

